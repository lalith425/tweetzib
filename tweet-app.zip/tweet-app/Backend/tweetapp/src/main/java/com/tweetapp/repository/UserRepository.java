package com.tweetapp.repository;

import java.util.List;

import com.tweetapp.model.Users;

import org.socialsignin.spring.data.dynamodb.repository.EnableScan;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
@EnableScan
public interface UserRepository extends CrudRepository<Users, String> {

    public Users findByLoginId(String loginId);

    public Users findByEmail(String email);

    // //@Query("{'loginId':{'$regex':?0, $options:'i'}}")
    // public List<Users> findSearchUsers(String loginId);

}
