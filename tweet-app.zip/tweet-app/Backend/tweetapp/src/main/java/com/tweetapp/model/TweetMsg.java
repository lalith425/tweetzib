package com.tweetapp.model;

import lombok.Data;

@Data
public class TweetMsg {
    String tweetMsg;

}
