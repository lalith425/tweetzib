package com.tweetapp.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import lombok.Getter;

@Component
@Getter
@RefreshScope
public class ConfigProperties {
    
    @Value("${kafka.host}")
    public String kafkaHost;

    @Value("${kafka.port}")
    public String kafkaPort;

}
