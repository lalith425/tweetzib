package com.tweetapp.repository;

import java.util.List;

import com.tweetapp.model.Tweet;

import org.socialsignin.spring.data.dynamodb.repository.EnableScan;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
@EnableScan
public interface TweetRepository extends CrudRepository<Tweet, String> {

    public List<Tweet> findByUserId(String userId);

    public Tweet findByTweetId(String tweetId);
}
