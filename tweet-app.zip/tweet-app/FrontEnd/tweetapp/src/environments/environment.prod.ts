export const environment = {
  production: true,
  baseUrl: 'http://localhost:4200'
};
