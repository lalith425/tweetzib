import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { RouterTestingModule } from '@angular/router/testing';
import { AuthServiceServiceService } from 'src/app/Service/auth-service-service.service';

import { LoginComponent } from './login.component';
class MockAuthService{

}

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoginComponent ],
      imports: [BrowserModule, FormsModule, ReactiveFormsModule, RouterTestingModule],
      providers: [
        {provide: AuthServiceServiceService, useClass: MockAuthService}
      ]
    })

    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('form should be invalid', ()=>{​
    component.loginForm.controls['username'].setValue('');
    component.loginForm.controls['password'].setValue('');
    expect(component.loginForm.valid).toBeFalsy();
  }​);
  it('form should be valid', ()=>{​
    component.loginForm.controls['username'].setValue('pal');
    component.loginForm.controls['password'].setValue('pwd');
    expect(component.loginForm.valid).toBeTruthy();
  }​);

});



    
  
    
    
  
  

