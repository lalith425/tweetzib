export interface Comments{

     userId: string;
     comment: string;
}