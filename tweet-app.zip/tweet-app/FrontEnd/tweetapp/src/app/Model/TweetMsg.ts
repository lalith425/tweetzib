export interface TweetMsg{

    tweetMsg: string;
}